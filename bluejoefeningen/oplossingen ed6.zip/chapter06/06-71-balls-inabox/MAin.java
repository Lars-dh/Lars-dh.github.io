public class MAin {
	public static void main(String[] args) {
		BallDemo bd = new BallDemo();
		bd.boxBounce(5);
	}
}
