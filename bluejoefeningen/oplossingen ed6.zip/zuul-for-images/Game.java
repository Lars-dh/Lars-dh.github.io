
/**
 * Write a description of class Game here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Game
{
	private UserInterface ui;
	private GameEngine engine;

    /**
     * Create the game and initialise its internal map.
     */
    public Game() 
    {
		engine = new GameEngine();
		ui = new TextInterface(engine);
		engine.setInterface(ui);
    }
    
    /**
     * Play the game.
     */
    public void play()
    {
        ui.takeControl();
    }
}
